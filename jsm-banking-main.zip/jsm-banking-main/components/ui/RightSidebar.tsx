import React from 'react'

const RightSidebar = ({
    user,
    transactions,
    banks
}: RightSidebarProps) => {
    return (
        <aside className='right-sidebar'>
            RIGHT
        </aside>
    )
}

export default RightSidebar